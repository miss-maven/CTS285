/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m1hw_calc;

import java.util.Scanner;

/**
 * M1HW CTS 285
 * 08/25/23
 * @author martinh5174
 */
public class SecondaryMenu 
{
   // method after math total to return to menu main or repeat same math choice
     public static void menu2Add ()
     {
             System.out.println("1. Repeat");
             System.out.println("2. Main Menu");
             System.out.print("Enter a number: ");
             Scanner scan = new Scanner(System.in);
             int menuChoice = scan.nextInt();
             if (menuChoice == 1)
                     {
                 Calculations.add(menuChoice, menuChoice);
             }
             else if (menuChoice == 2)
                     {
                 Menu.MainMenu();
             }
                     }
                
}
