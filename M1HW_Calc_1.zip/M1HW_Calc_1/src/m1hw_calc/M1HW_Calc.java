/*
 * Java program for simple calculator for CTS 285
 * HJane Martin 8/22/23
 */
package m1hw_calc;

/**
 *  M1HW CTS 285
 * 08/25/23
 * @author martinhj
 */
// 2
//import SecondaryMenu;
import java.util.Scanner;

public class M1HW_Calc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Display welcome and menu of options for user
//        System.out.println("Welcome to the calculator program.");
//        System.out.println("1. Add");
//        System.out.println("2. Subtract");
//        System.out.println("3. Divide");
//        System.out.println("4. Multiply");
//        System.out.println("5. Exit");
     //1   System.out.print(MainMenu);
        // Store two doubles in case of decimal math 
        double num1 = 0, num2 = 0;
        double total = 0;
        int option;
        // Get user input of numbers 
        Scanner scan = new Scanner(System.in);
        // USER OUTPUT NEEDS TO BE BOLD!!! jk no it doesnttttttt
        // Store menu number user chose as option
        Menu.MainMenu();
        System.out.print("Enter a number: ");
        option = scan.nextInt();
       
     //seconadry menu needs called after each total?
     // 1. repeat 2. main menu - send to main menu or send to exit goodbye
        
     // if else statements to call calculations for each math menu option 
     // last else for goodbye end program
        if (option == 1){
           Calculations.add(num1, num2);
        }
        else if (option == 2){
            Calculations.subtract(num1, num2);
        }
        else if (option == 3) {
            Calculations.divide(num1, num2);
        }
        else if (option == 4){
            Calculations.multiply(num1, num2);
        }
        else if (option == 5) {
            System.out.println("Goodbye.");
        }
    }

        // switch for calling methods of each calculation 
        // switch (option) {
           // case 1: Add
           //          break;
                     
        }
    
    

