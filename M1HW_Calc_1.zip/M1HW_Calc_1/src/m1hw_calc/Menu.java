/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m1hw_calc;

/**
 * M1HW CTS285
 * @author martinHJ5174
 */
public class Menu 
{
    public static void MainMenu() {
    // Display welcome and menu of options for user
        System.out.println("Welcome to the calculator program.");
        System.out.println("1. Add");
        System.out.println("2. Subtract");
        System.out.println("3. Divide");
        System.out.println("4. Multiply");
        System.out.println("5. Exit");
}
}