/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m1hw_calc;

import java.util.Scanner;

/**
 * M1HW CTS285
 * 08/25/23
 * @author martinHJ5174
 */
public class Calculations
{
     public static void add(double num1, double num2){
       // calculations for program to store 2 user numbers and do according math
       // add secondary method call for the menu AFTER math total is displayed
            Scanner scan = new Scanner(System.in);
            System.out.print("Enter the first number:");
            num1 = scan.nextDouble();
            System.out.print("Enter the second number:");
            num2 = scan.nextDouble();
            double total = (num1 + num2);
            System.out.println(total);
            SecondaryMenu.menu2Add();
        }
        
        public static void subtract(double num1, double num2) {
            
            Scanner scan = new Scanner(System.in);
            System.out.print("Enter the first number:");
            num1 = scan.nextDouble();
            System.out.print("Enter the second number:");
            num2 = scan.nextDouble();
            double total = (num1 - num2);
            System.out.println(num1 + "-" + num2 + "=" + total);
            SecondaryMenu.menu2Add();
        }
        
        public static void divide(double num1, double num2){
            
            Scanner scan = new Scanner(System.in);
            System.out.print("Enter the first number:");
            num1 = scan.nextDouble();
            System.out.print("Enter the second number:");
            num2 = scan.nextDouble();
            double total = (num1 / num2);
            System.out.println(num1 + "divided by" + num2 + "=" + total);
            SecondaryMenu.menu2Add();
        }
        
        public static void multiply(double num1, double num2){ 
           
            Scanner scan = new Scanner(System.in);
            System.out.print("Enter the first number:");
            num1 = scan.nextDouble();
            System.out.print("Enter the second number:");
            num2 = scan.nextDouble();
            double total = (num1 * num2);
            System.out.println(num1 + " x " + num2 + " = " + total);
            SecondaryMenu.menu2Add();
        }
}
